'''
Created on Jun 15, 2019
@author: Burkhard A. Meier
'''

import wx
app = wx.App()
frame = wx.Frame(None, -1, "Hello World")
frame.Show()
app.MainLoop()
