'''
Created on May 3, 2019

@author: Burkhard A. Meier
'''

from tkinter import messagebox as msg
from tkinter import Tk
root = Tk()
root.withdraw()
msg.showinfo('This is a Title', 'Python GUI created using tkinter:\nThe year is 2019')
