'''
Created on Jul 26, 2019
Chapter 05
@author: Burkhard
'''


import matplotlib.pyplot as plt
from pylab import show

x_values = [1,2,3,4] 
y_values = [5,7,6,8] 
plt.plot(x_values, y_values)

show()              
